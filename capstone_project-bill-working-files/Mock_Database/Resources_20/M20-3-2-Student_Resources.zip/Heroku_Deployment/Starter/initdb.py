from pet_pals.app import db

# db.drop_all()
db.create_all()
